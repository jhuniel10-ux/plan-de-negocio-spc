PLAN DE NEGOCIO SPC - GitHub Pages

ARCHIVO PRINCIPAL:
index.html

PARA PUBLICAR:
1. En el repositorio plan-de-negocio-spc, selecciona "sube uno existente".
2. Descomprime este ZIP en tu computadora.
3. Sube el archivo index.html al repositorio.
4. Confirma los cambios.
5. Ve a Settings > Pages.
6. En Source selecciona "Deploy from a branch".
7. Branch: main / (root).
8. Guarda y espera unos minutos.

El aplicativo incluye el logo, ejemplos, costos fijos y variables,
cálculos automáticos, guardado local, descarga Word e impresión/PDF.
